# assingmentGamaAcademy
Primeiro desafio Gama Academy

Build with Bootstrap 4.1

Information data with WebHook
end Point

https://hooks.zapier.com/hooks/catch/1735454/oh5cwc6/

Body requisition method POST
<code>
{
	"name": "Douglas Morais Souza",
	"email": "mr.douglasmorais23@gmail.com",
	"phone": "11980358443",
	"timestamps": "2018-08-20'T'13:20:10*633+0000",
	"ip": "187.37.67.66"
}
</code>


Instructions:
